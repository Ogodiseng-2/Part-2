
package chatmessagingapplication;
import javax.swing.JOptionPane;

public class Chatmessagingapplication {

    /**
     * Main method that runs the registration and login process.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        Registration registration = new Registration();

        //  FIRST NAME 

        String firstName;

        while (true) {

            firstName = JOptionPane.showInputDialog(
                    null,
                    "Enter your first name:"
            );

            if (firstName != null
                    && !firstName.isBlank()
                    && firstName.matches("^[a-zA-Z]+$")) {

                JOptionPane.showMessageDialog(
                        null,
                        "First name successfully captured."
                );

                break;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "First name is invalid. Please enter letters only."
                );
            }
        }

        //  LAST NAME 

        String lastName;

        while (true) {

            lastName = JOptionPane.showInputDialog(
                    null,
                    "Enter your last name:"
            );

            if (lastName != null
                    && !lastName.isBlank()
                    && lastName.matches("^[a-zA-Z]+$")) {

                JOptionPane.showMessageDialog(
                        null,
                        "Last name successfully captured."
                );

                break;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Last name is invalid. Please enter letters only."
                );
            }
        }

        //  USERNAME 
        String username;

        while (true) {

            username = JOptionPane.showInputDialog(
                    null,
                    "Enter your username:\n"
                    + "Username must contain an underscore (_)\n"
                    + "and must be no more than 5 characters."
            );

            if (registration.checkUserName(username)) {

                registration.setUserName(username);

                JOptionPane.showMessageDialog(
                        null,
                        "Username successfully captured."
                );

                break;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Username is not correctly formatted, "
                        + "please ensure that your username contains "
                        + "an underscore and is no more than five "
                        + "characters in length."
                );
            }
        }

        // PASSWORD 

        String password;

        while (true) {

            password = JOptionPane.showInputDialog(
                    null,
                    "Enter your password:\n"
                    + "Password must be at least 8 characters long,\n"
                    + "contain a capital letter, a number and a special character."
            );

            if (registration.checkPasswordComplexity(password)) {

                registration.setPassword(password);

                JOptionPane.showMessageDialog(
                        null,
                        "Password successfully captured."
                );

                break;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Password is not correctly formatted; "
                        + "please ensure that the password contains "
                        + "at least eight characters, a capital letter, "
                        + "a number, and a special character."
                );
            }
        }

        //  CELL PHONE 

        String cellPhoneNumber;

        while (true) {

            cellPhoneNumber = JOptionPane.showInputDialog(
                    null,
                    "Enter your South African cell phone number:\n"
                    + "Example: +27838968976"
            );

            if (registration.checkCellPhoneNumber(cellPhoneNumber)) {

                registration.setCellPhoneNumber(cellPhoneNumber);

                JOptionPane.showMessageDialog(
                        null,
                        "Cell phone number successfully added."
                );

                break;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Cell phone number incorrectly formatted "
                        + "or does not contain international code."
                );
            }
        }

        //  REGISTRATION 

        String registrationResult = registration.registerUser(
                username,
                password,
                cellPhoneNumber,
                firstName,
                lastName
        );

        JOptionPane.showMessageDialog(
                null,
                registrationResult
        );

        // LOGIN 

        if (registrationResult.equals("Registration successful.")) {

            Login login = new Login(registration);

            String loginUsername;
            String loginPassword;

            while (true) {

                loginUsername = JOptionPane.showInputDialog(
                        null,
                        "Enter your username to login:"
                );

                loginPassword = JOptionPane.showInputDialog(
                        null,
                        "Enter your password to login:"
                );

                if (login.loginUser(loginUsername, loginPassword)) {

                  if (login.loginUser(loginUsername, loginPassword)) {

    JOptionPane.showMessageDialog(
            null,
            login.returnLoginStatus()
    );

    // Open QuickChat only after successful login
    MessagingMenu messagingMenu = new MessagingMenu();
    messagingMenu.runMenu();

    break;

}

                } else {

                    JOptionPane.showMessageDialog(
                            null,
                            login.returnLoginStatus()
                    );
                }
            }
        }
    }
}