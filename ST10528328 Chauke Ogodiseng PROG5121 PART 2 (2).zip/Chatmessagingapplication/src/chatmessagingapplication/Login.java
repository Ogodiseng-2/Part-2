
package chatmessagingapplication;

/**
 * Handles user authentication.
 *
 * @author RC_Student_lab
 */
public class Login {

    private final Registration registration;
    private boolean accessGranted;

    /**
     * Creates a Login object using registered user information.
     *
     * @param registration registered user information
     */
    public Login(Registration registration) {
        this.registration = registration;
        this.accessGranted = false;
    }

    /**
     * Checks whether the username is correctly formatted.
     *
     * @param userName username to check
     * @return true if username is valid
     */
    public boolean checkUserName(String userName) {
        return registration.checkUserName(userName);
    }

    /**
     * Checks whether the password meets complexity requirements.
     *
     * @param password password to check
     * @return true if password is valid
     */
    public boolean checkPasswordComplexity(String password) {
        return registration.checkPasswordComplexity(password);
    }

    /**
     * Checks whether the cell phone number is correctly formatted.
     *
     * @param cellPhoneNumber cell phone number to check
     * @return true if number is valid
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return registration.checkCellPhoneNumber(cellPhoneNumber);
    }

    /**
     * Attempts to authenticate the user.
     *
     * @param userNameAttempt username entered during login
     * @param passwordAttempt password entered during login
     * @return true if the login details match
     */
    public boolean loginUser(
            String userNameAttempt,
            String passwordAttempt) {

        accessGranted = userNameAttempt != null
                && passwordAttempt != null
                && userNameAttempt.equals(registration.getUserName())
                && passwordAttempt.equals(registration.getPassword());

        return accessGranted;
    }

    /**
     * Returns the appropriate login status message.
     *
     * @return successful or failed login message
     */
    public String returnLoginStatus() {

        if (accessGranted) {
            return "Welcome "
                    + registration.getFirstName()
                    + " "
                    + registration.getLastName()
                    + ", it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    /**
     * Returns the registered username.
     *
     * @return registered username
     */
    public String getUsername() {
        return registration.getUserName();
    }
}