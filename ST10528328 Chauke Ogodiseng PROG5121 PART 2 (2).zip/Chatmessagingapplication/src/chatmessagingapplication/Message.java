
package chatmessagingapplication;
import java.util.regex.Pattern;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.JOptionPane;

public class Message {

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private String status;

    private static int nextMessageNumber = 0;
    private static int totalMessagesSent = 0;

    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = nextMessageNumber++;
        this.recipient = recipient == null ? "" : recipient.trim();
        this.messageText = messageText == null ? "" : messageText.trim();
        this.messageHash = createMessageHash();
        this.status = "Pending";
    }

    private static String generateMessageID() {
        long id = ThreadLocalRandom.current().nextLong(
                1_000_000_000L, 10_000_000_000L);
        return String.valueOf(id);
    }
    public static int returnTotalMessagess() {
    return totalMessagesSent;
}

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("\\d{10}");
    }

    // Returns 1 for a valid number and 0 for an invalid number.
    // Follows the POE example: +27 followed by nine digits.
    public int checkRecipientCell() {
        return recipient.matches("^\\+27\\d{9}$") ? 1 : 0;
    }

    public String recipientValidationMessage() {
        if (checkRecipientCell() == 1) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public boolean isMessageLengthValid() {
        return !messageText.isEmpty() && messageText.length() <= 250;
    }

    public String messageLengthValidationMessage() {
        if (isMessageLengthValid()) {
            return "Message ready to send.";
        }

        if (messageText.length() > 250) {
            return "Message exceeds 250 characters by "
                    + (messageText.length() - 250)
                    + ", please reduce size.";
        }

        return "Please enter a message.";
    }

    public String createMessageHash() {
        String firstTwoDigits = messageID.substring(0, 2);

        if (messageText.trim().isEmpty()) {
            return (firstTwoDigits + ":" + messageNumber + ":")
                    .toUpperCase();
        }

        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1]
                .replaceAll("[^A-Za-z0-9]", "");

        return (firstTwoDigits + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // Displays the three message options.
    public String SentMessage() {
        Object[] options = {
            "Send Message",
            "Disregard Message",
            "Store Message to send later"
        };

        int choice = JOptionPane.showOptionDialog(
                null,
                "What would you like to do with this message?",
                "QuickChat",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == -1) {
            return "No option selected.";
        }

        String result = processChoice(choice);

        if (choice == 0 && result.equals("Message successfully sent.")) {
            JOptionPane.showMessageDialog(
                    null,
                    "MessageID: " + messageID
                    + "\nMessage Hash: " + messageHash
                    + "\nRecipient: " + recipient
                    + "\nMessage: " + messageText,
                    "Message Details",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }

        return result;
    }

    // Processes a choice separately so the options can be unit tested.
    // 0 = Send, 1 = Disregard, 2 = Store.
    public String processChoice(int choice) {
        if (!isMessageLengthValid()) {
            return messageLengthValidationMessage();
        }

        if (checkRecipientCell() != 1) {
            return recipientValidationMessage();
        }

        switch (choice) {
            case 0:
                status = "Sent";
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";

            case 1:
                status = "Disregarded";
                disregardedMessages.add(this);
                return "Press 0 to delete message.";

            case 2:
                status = "Stored";

                try {
                    storeMessage();
                    storedMessages.add(this);
                    return "Message successfully stored.";
                } catch (IOException e) {
                    status = "Pending";
                    return "Message could not be stored.";
                }

            default:
                return "Invalid message option.";
        }
    }

    // Returns details of all messages sent during this program run.
    public String printMessages() {
        StringBuilder output = new StringBuilder();

        for (Message message : sentMessages) {
            output.append("MessageID: ")
                    .append(message.messageID)
                    .append("\nMessage Hash: ")
                    .append(message.messageHash)
                    .append("\nRecipient: ")
                    .append(message.recipient)
                    .append("\nMessage: ")
                    .append(message.messageText)
                    .append("\n\n");
        }

        return output.toString().trim();
    }

   
    // Appends this message to messages.json.
    public void storeMessage() throws IOException {
        String fileName = "messages.json";
        String existing = "";

        if (Files.exists(Paths.get(fileName))) {
            existing = new String(
                    Files.readAllBytes(Paths.get(fileName)),
                    StandardCharsets.UTF_8
            ).trim();
        }

        String jsonObject = "{"
                + "\"messageID\":\"" + escapeJSON(messageID) + "\","
                + "\"messageNumber\":" + messageNumber + ","
                + "\"recipient\":\"" + escapeJSON(recipient) + "\","
                + "\"message\":\"" + escapeJSON(messageText) + "\","
                + "\"messageHash\":\"" + escapeJSON(messageHash) + "\","
                + "\"status\":\"" + escapeJSON(status) + "\""
                + "}";

        String updated;

        if (existing.isEmpty() || existing.equals("[]")) {
            updated = "[" + jsonObject + "]";
        } else if (existing.startsWith("[") && existing.endsWith("]")) {
            String inside = existing.substring(1, existing.length() - 1)
                    .trim();

            updated = inside.isEmpty()
                    ? "[" + jsonObject + "]"
                    : "[" + inside + "," + jsonObject + "]";
        } else {
            throw new IOException("Existing JSON file is not a JSON array.");
        }

        Files.write(
                Paths.get(fileName),
                updated.getBytes(StandardCharsets.UTF_8)
        );
    }

    private static String escapeJSON(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }

    public static List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public static List<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public static List<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    // Used by unit tests to reset the shared message data.
    static void resetForTests() {
        nextMessageNumber = 0;
        totalMessagesSent = 0;
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
    }
}
