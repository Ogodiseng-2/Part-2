package chatmessagingapplication;

import javax.swing.JOptionPane;

public class MessagingMenu {

    public void runMenu() {

        JOptionPane.showMessageDialog(
                null,
                "Welcome to QuickChat."
        );

        while (true) {

            String choice = JOptionPane.showInputDialog(
                    null,
                    "QUICKCHAT MENU\n\n"
                    + "1. Send Messages\n"
                    + "2. Show recently sent messages\n"
                    + "3. Quit\n\n"
                    + "Enter your choice:"
            );

            // Stop if the user cancels
            if (choice == null) {
                break;
            }

            switch (choice.trim()) {

                case "1":
                    sendMessages();
                    break;

                case "2":
                    JOptionPane.showMessageDialog(
                            null,
                            "Coming Soon."
                    );
                    break;

                case "3":
                    JOptionPane.showMessageDialog(
                            null,
                            "Thank you for using QuickChat."
                    );
                    return;

                default:
                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid choice. Please enter 1, 2 or 3."
                    );
            }
        }
    }

    private void sendMessages() {

        String input = JOptionPane.showInputDialog(
                null,
                "How many messages would you like to send?"
        );

        if (input == null) {
            return;
        }

        int numberOfMessages;

        try {
            numberOfMessages = Integer.parseInt(input.trim());

            if (numberOfMessages <= 0) {
                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a number greater than zero."
                );
                return;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid whole number."
            );
            return;
        }

        for (int i = 0; i < numberOfMessages; i++) {

            String recipient = JOptionPane.showInputDialog(
                    null,
                    "Message " + (i + 1)
                    + " of " + numberOfMessages
                    + "\nEnter recipient number:"
            );

            if (recipient == null) {
                return;
            }

            String messageText = JOptionPane.showInputDialog(
                    null,
                    "Enter your message (maximum 250 characters):"
            );

            if (messageText == null) {
                return;
            }

            Message message = new Message(
                    recipient,
                    messageText
            );

            message.SentMessage();
        }

        JOptionPane.showMessageDialog(null,
               Message.returnTotalMessagess()
              + "Total messages sent: "
        );
    }
}