
package chatmessagingapplication;

import java.util.regex.Pattern;

/**
 * Handles user registration and validation.
 *
 * @author mmatl
 */
public class Registration {

    private String storedUserName;
    private String storedPassword;
    private String storedCellPhoneNumber;
    private String storedFirstName;
    private String storedLastName;

    /**
     * Checks whether the username is correctly formatted.
     * The username must contain an underscore and be no more than
     * five characters long.
     *
     * @param userName username to check
     * @return true if the username is valid, otherwise false
     */
    public boolean checkUserName(String userName) {

        if (userName == null || userName.isBlank()) {
            return false;
        }

        return userName.contains("_") && userName.length() <= 5;
    }

    /**
     * Checks whether the password meets the required complexity.
     * The password must be at least eight characters long and contain
     * a capital letter, a number and a special character.
     *
     * @param password password to check
     * @return true if the password is valid, otherwise false
     */
    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.isBlank()) {
            return false;
        }

        if (password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char character : password.toCharArray()) {

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Checks whether the cellphone number is correctly formatted.
     * The number must start with +27 followed by nine digits.
     *
     * @param cellPhoneNumber cellphone number to check
     * @return true if the cellphone number is valid, otherwise false
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {

        if (cellPhoneNumber == null || cellPhoneNumber.isBlank()) {
            return false;
        }

        return Pattern.matches(
                "^\\+27[0-9]{9}$",
                cellPhoneNumber
        );
    }

    /**
     * Stores the username if it is valid.
     *
     * @param userName username to store
     * @return true if the username is valid, otherwise false
     */
    public boolean setUserName(String userName) {

        if (checkUserName(userName)) {
            storedUserName = userName;
            return true;
        }

        return false;
    }

    /**
     * Stores the password if it is valid.
     *
     * @param password password to store
     * @return true if the password is valid, otherwise false
     */
    public boolean setPassword(String password) {

        if (checkPasswordComplexity(password)) {
            storedPassword = password;
            return true;
        }

        return false;
    }

    /**
     * Stores the cellphone number if it is valid.
     *
     * @param cellPhoneNumber cellphone number to store
     * @return true if the cellphone number is valid, otherwise false
     */
    public boolean setCellPhoneNumber(String cellPhoneNumber) {

        if (checkCellPhoneNumber(cellPhoneNumber)) {
            storedCellPhoneNumber = cellPhoneNumber;
            return true;
        }

        return false;
    }

    /**
     * Stores the first name if it is valid.
     *
     * @param firstName first name to store
     * @return true if the first name is valid, otherwise false
     */
    public boolean setFirstName(String firstName) {

        if (checkName(firstName)) {
            storedFirstName = firstName;
            return true;
        }

        return false;
    }

    /**
     * Stores the last name if it is valid.
     *
     * @param lastName last name to store
     * @return true if the last name is valid, otherwise false
     */
    public boolean setLastName(String lastName) {

        if (checkName(lastName)) {
            storedLastName = lastName;
            return true;
        }

        return false;
    }

    /**
     * Checks whether a name is valid.
     *
     * @param name name to check
     * @return true if the name contains letters and is not empty
     */
    private boolean checkName(String name) {

        return name != null
                && !name.isBlank()
                && name.matches("^[a-zA-Z]+$");
    }

    /**
     * Registers all user information.
     *
     * @param newUserName username
     * @param newPassword password
     * @param newCellPhoneNumber cellphone number
     * @param newFirstName first name
     * @param newLastName last name
     * @return registration result
     */
    public String registerUser(
            String newUserName,
            String newPassword,
            String newCellPhoneNumber,
            String newFirstName,
            String newLastName) {

        boolean usernameValid = setUserName(newUserName);
        boolean passwordValid = setPassword(newPassword);
        boolean cellPhoneValid = setCellPhoneNumber(newCellPhoneNumber);
        boolean firstNameValid = setFirstName(newFirstName);
        boolean lastNameValid = setLastName(newLastName);

        if (usernameValid
                && passwordValid
                && cellPhoneValid
                && firstNameValid
                && lastNameValid) {

            return "Registration successful.";
        }

        return "Registration failed.";
    }

    /**
     * Gets the stored username.
     *
     * @return username
     */
    public String getUserName() {
        return storedUserName;
    }

    /**
     * Gets the stored password.
     *
     * @return password
     */
    public String getPassword() {
        return storedPassword;
    }

    /**
     * Gets the stored cellphone number.
     *
     * @return cellphone number
     */
    public String getCellPhoneNumber() {
        return storedCellPhoneNumber;
    }

    /**
     * Gets the stored first name.
     *
     * @return first name
     */
    public String getFirstName() {
        return storedFirstName;
    }

    /**
     * Gets the stored last name.
     *
     * @return last name
     */
    public String getLastName() {
        return storedLastName;
    }
}

