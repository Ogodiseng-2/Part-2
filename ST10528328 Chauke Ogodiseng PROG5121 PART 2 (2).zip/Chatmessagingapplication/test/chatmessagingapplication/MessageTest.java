
package chatmessagingapplication;


import org.junit.Before;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Before
    public void setUp() {
        Message.resetForTests();
    }

    @Test
    public void messageIDMustContainTenDigits() {
        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight"
        );

        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    @Test
    public void validRecipientIsAccepted() {
        Message message = new Message(
                "+27718693002",
                "Hello"
        );

        assertEquals(1, message.checkRecipientCell());
        assertEquals(
                "Cell phone number successfully captured.",
                message.recipientValidationMessage()
        );
    }

    @Test
    public void invalidRecipientIsRejected() {
        Message message = new Message(
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );

        assertEquals(0, message.checkRecipientCell());
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message.recipientValidationMessage()
        );
    }

    @Test
    public void messageUnder250CharactersIsValid() {
        Message message = new Message(
                "+27718693002",
                "Hello"
        );

        assertTrue(message.isMessageLengthValid());
        assertEquals(
                "Message ready to send.",
                message.messageLengthValidationMessage()
        );
    }

    @Test
    public void messageOver250CharactersIsRejected() {
        String longText = new String(new char[253]).replace('\0', 'A');

        Message message = new Message(
                "+27718693002",
                longText
        );

        assertFalse(message.isMessageLengthValid());
        assertEquals(
                "Message exceeds 250 characters by 3, please reduce size.",
                message.messageLengthValidationMessage()
        );
    }

    @Test
    public void messageHashUsesFirstAndLastWords() {
        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight"
        );

        String expected = message.getMessageID().substring(0, 2)
                + ":0:HITONIGHT";

        assertEquals(expected, message.createMessageHash());
    }

    @Test
    public void sendingMessageIncreasesTotalSent() {
        Message message = new Message(
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight"
        );

        assertEquals(
                "Message successfully sent.",
                message.processChoice(0)
        );

        assertEquals(1, Message.returnTotalMessagess());
        assertEquals(1, Message.getSentMessages().size());
    }

    @Test
    public void disregardingMessageDoesNotIncreaseSentCount() {
        Message message = new Message(
                "+27718693002",
                "Hi Keegan"
        );

        assertEquals(
                "Press 0 to delete message.",
                message.processChoice(1)
        );

        assertEquals(0, Message.returnTotalMessagess());
        assertEquals(1, Message.getDisregardedMessages().size());
    }

    @Test
    public void storingMessageDoesNotIncreaseSentCount() {
        Message message = new Message(
                "+27718693002",
                "I will send this later"
        );

        assertEquals(
                "Message successfully stored.",
                message.processChoice(2)
        );

        assertEquals(0, Message.returnTotalMessagess());
        assertEquals(1, Message.getStoredMessages().size());
    }
}
