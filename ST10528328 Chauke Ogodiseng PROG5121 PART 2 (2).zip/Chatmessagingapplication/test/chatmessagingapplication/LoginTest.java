/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java
 * to edit this template
 */
package chatmessagingapplication;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author mmatl
 */
public class LoginTest {

    private Registration registration;
    private Login login;

    public LoginTest() {
    }

    @BeforeEach
    public void setUp() {

        registration = new Registration();

        registration.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "John",
                "Smith"
        );

        login = new Login(registration);
    }

    @AfterEach
    public void tearDown() {
        login = null;
        registration = null;
    }

    @Test
    public void testCheckUserName() {

        assertTrue(
                login.checkUserName("kyl_1")
        );

        assertFalse(
                login.checkUserName("kyle!!!!!!!")
        );
    }

    @Test
    public void testCheckPasswordComplexity() {

        assertTrue(
                login.checkPasswordComplexity("Ch&&sec@ke99!")
        );

        assertFalse(
                login.checkPasswordComplexity("password")
        );
    }

    @Test
    public void testCheckCellPhoneNumber() {

        assertTrue(
                login.checkCellPhoneNumber("+27838968976")
        );

        assertFalse(
                login.checkCellPhoneNumber("08966553")
        );
    }

    @Test
    public void testLoginUser() {

        assertTrue(
                login.loginUser(
                        "kyl_1",
                        "Ch&&sec@ke99!"
                )
        );

        assertFalse(
                login.loginUser(
                        "wrong",
                        "wrong"
                )
        );
    }

    @Test
    public void testReturnLoginStatus() {

        login.loginUser(
                "kyl_1",
                "Ch&&sec@ke99!"
        );

        assertEquals(
                "Welcome John Smith, it is great to see you again.",
                login.returnLoginStatus()
        );

        login.loginUser(
                "wrong",
                "wrong"
        );

        assertEquals(
                "Username or password incorrect, please try again.",
                login.returnLoginStatus()
        );
    }

    @Test
    public void testGetUsername() {

        assertEquals(
                "kyl_1",
                login.getUsername()
        );
    }
}
