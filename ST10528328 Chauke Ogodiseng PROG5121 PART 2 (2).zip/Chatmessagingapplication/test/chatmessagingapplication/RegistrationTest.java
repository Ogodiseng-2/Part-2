
package chatmessagingapplication;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author mmatl
 */
public class RegistrationTest {

    private Registration registration;

    public RegistrationTest() {
    }

    @BeforeEach
    public void setUp() {
        registration = new Registration();
    }

    @AfterEach
    public void tearDown() {
        registration = null;
    }

    @Test
    public void testCheckUserName() {
        assertTrue(registration.checkUserName("kyl_1"));
        assertFalse(registration.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(
                registration.checkPasswordComplexity("Ch&&sec@ke99!")
        );

        assertFalse(
                registration.checkPasswordComplexity("password")
        );
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(
                registration.checkCellPhoneNumber("+27838968976")
        );

        assertFalse(
                registration.checkCellPhoneNumber("08966553")
        );
    }

    @Test
    public void testSetUserName() {
        assertTrue(
                registration.setUserName("kyl_1")
        );

        assertFalse(
                registration.setUserName("kyle!!!!!!!")
        );
    }

    @Test
    public void testSetPassword() {
        assertTrue(
                registration.setPassword("Ch&&sec@ke99!")
        );

        assertFalse(
                registration.setPassword("password")
        );
    }

    @Test
    public void testSetCellPhoneNumber() {
        assertTrue(
                registration.setCellPhoneNumber("+27838968976")
        );

        assertFalse(
                registration.setCellPhoneNumber("08966553")
        );
    }

    @Test
    public void testSetFirstName() {
        assertTrue(
                registration.setFirstName("John")
        );

        assertFalse(
                registration.setFirstName("")
        );
    }

    @Test
    public void testSetLastName() {
        assertTrue(
                registration.setLastName("Smith")
        );

        assertFalse(
                registration.setLastName("")
        );
    }

    @Test
    public void testRegisterUser() {
        String result = registration.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "John",
                "Smith"
        );

        assertEquals(
                "Registration successful.",
                result
        );
    }

    @Test
    public void testGetUserName() {
        registration.setUserName("kyl_1");

        assertEquals(
                "kyl_1",
                registration.getUserName()
        );
    }

    @Test
    public void testGetPassword() {
        registration.setPassword("Ch&&sec@ke99!");

        assertEquals(
                "Ch&&sec@ke99!",
                registration.getPassword()
        );
    }

    @Test
    public void testGetCellPhoneNumber() {
        registration.setCellPhoneNumber("+27838968976");

        assertEquals(
                "+27838968976",
                registration.getCellPhoneNumber()
        );
    }

    @Test
    public void testGetFirstName() {
        registration.setFirstName("John");

        assertEquals(
                "John",
                registration.getFirstName()
        );
    }

    @Test
    public void testGetLastName() {
        registration.setLastName("Smith");

        assertEquals(
                "Smith",
                registration.getLastName()
        );
    }
}
